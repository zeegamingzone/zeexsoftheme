
export interface BlogSection {
  type: 'heading' | 'paragraph' | 'image' | 'code' | 'list';
  content?: string;
  items?: string[];
  alt?: string;
  caption?: string;
}

export interface Blog {
  id: number;
  title: string;
  slug: string;
  excerpt: string;
  content: BlogSection[];
  image: string;
  date: string;
  readTime: number;
  author: string;
  category: string;
  featured?: boolean;
}

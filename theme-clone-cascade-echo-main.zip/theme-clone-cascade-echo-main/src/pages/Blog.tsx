
import { useState, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import BlogCard from '@/components/BlogCard';
import BlogFeatured from '@/components/BlogFeatured';
import BlogCategories from '@/components/BlogCategories';
import { Pagination, PaginationContent, PaginationItem, PaginationLink, PaginationNext, PaginationPrevious } from "@/components/ui/pagination";
import { Blog } from '@/types/blog';
import { sampleBlogs } from '@/data/sampleBlogs';

const BlogPage = () => {
  const [blogs, setBlogs] = useState<Blog[]>(sampleBlogs);
  const [activeCategory, setActiveCategory] = useState<string>("all");
  const [currentPage, setCurrentPage] = useState(1);
  const { toast } = useToast();
  
  const blogsPerPage = 6;
  const indexOfLastBlog = currentPage * blogsPerPage;
  const indexOfFirstBlog = indexOfLastBlog - blogsPerPage;
  
  // Filter blogs by category
  const filteredBlogs = activeCategory === "all" 
    ? blogs 
    : blogs.filter(blog => blog.category === activeCategory);
  
  const currentBlogs = filteredBlogs.slice(indexOfFirstBlog, indexOfLastBlog);
  const featuredBlog = blogs.find(blog => blog.featured);
  
  const paginate = (pageNumber: number) => setCurrentPage(pageNumber);
  
  const handleCategoryChange = (category: string) => {
    setActiveCategory(category);
    setCurrentPage(1);
  };
  
  // Animation for blog cards
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry, index) => {
          if (entry.isIntersecting) {
            setTimeout(() => {
              entry.target.classList.add('animate-fade-in');
              observer.unobserve(entry.target);
            }, index * 100); // Staggered animation
          }
        });
      },
      { threshold: 0.1 }
    );
    
    document.querySelectorAll('.blog-card').forEach(card => {
      observer.observe(card);
    });
    
    return () => observer.disconnect();
  }, [currentBlogs, activeCategory]);
  
  // Simulate WordPress API loading
  useEffect(() => {
    toast({
      title: "Blog Posts Loaded",
      description: "Successfully fetched latest posts from WordPress API",
    });
  }, []);
  
  return (
    <div className="flex flex-col min-h-screen">
      <Navigation />
      <main className="flex-grow">
        {/* Hero Banner */}
        <section className="relative overflow-hidden pt-24 pb-10 mb-10 dark:bg-gradient-to-br dark:from-theme-dark dark:to-[#161a23] bg-gradient-to-br from-white to-gray-100">
          <div className="absolute inset-0 overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-b dark:from-theme-purple/10 dark:to-theme-dark/0 from-theme-purple/5 to-white/0"></div>
            <div className="absolute -top-[500px] -right-[300px] w-[800px] h-[800px] rounded-full bg-theme-purple/10 blur-3xl dark:bg-theme-purple/5"></div>
            <div className="absolute -bottom-[300px] -left-[200px] w-[600px] h-[600px] rounded-full bg-theme-purple/10 blur-3xl dark:bg-theme-purple/5"></div>
          </div>
          <div className="container mx-auto px-4 relative">
            <div className="text-center animate-fade-in">
              <h1 className="text-4xl md:text-6xl font-bold mb-6">
                ZeeX Soft <span className="gradient-text">Blog</span>
              </h1>
              <p className="dark:text-gray-400 text-gray-600 text-lg max-w-2xl mx-auto">
                Latest insights, tutorials, and updates on Android app development and technology trends
              </p>
            </div>
          </div>
        </section>
        
        <div className="container mx-auto px-4 pb-16">
          {/* Featured Blog Post */}
          {featuredBlog && <BlogFeatured blog={featuredBlog} />}
          
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 mt-16">
            {/* Categories Sidebar */}
            <BlogCategories activeCategory={activeCategory} onCategoryChange={handleCategoryChange} />
            
            {/* Blog Posts Grid */}
            <div className="lg:col-span-3">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {currentBlogs.map((blog) => (
                  <div key={blog.id} className="blog-card opacity-0">
                    <BlogCard blog={blog} />
                  </div>
                ))}
              </div>
              
              {/* Empty State */}
              {currentBlogs.length === 0 && (
                <div className="text-center py-20">
                  <h3 className="text-xl mb-2">No blog posts found</h3>
                  <p className="dark:text-gray-400 text-gray-600">Try selecting a different category</p>
                </div>
              )}
              
              {/* Pagination */}
              {filteredBlogs.length > blogsPerPage && (
                <Pagination className="mt-10">
                  <PaginationContent>
                    <PaginationItem>
                      <PaginationPrevious 
                        onClick={() => currentPage > 1 && paginate(currentPage - 1)}
                        className={currentPage === 1 ? "pointer-events-none opacity-50" : ""} 
                      />
                    </PaginationItem>
                    
                    {Array(Math.ceil(filteredBlogs.length / blogsPerPage))
                      .fill(0)
                      .map((_, index) => (
                        <PaginationItem key={index}>
                          <PaginationLink
                            onClick={() => paginate(index + 1)}
                            isActive={currentPage === index + 1}
                          >
                            {index + 1}
                          </PaginationLink>
                        </PaginationItem>
                      ))}
                      
                    <PaginationItem>
                      <PaginationNext 
                        onClick={() => currentPage < Math.ceil(filteredBlogs.length / blogsPerPage) && paginate(currentPage + 1)} 
                        className={currentPage === Math.ceil(filteredBlogs.length / blogsPerPage) ? "pointer-events-none opacity-50" : ""}
                      />
                    </PaginationItem>
                  </PaginationContent>
                </Pagination>
              )}
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default BlogPage;

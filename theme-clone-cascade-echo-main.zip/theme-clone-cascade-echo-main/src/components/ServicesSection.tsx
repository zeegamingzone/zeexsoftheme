
import { 
  Smartphone, Code, Layout, Shield, Database, Headphones, 
  Monitor, LineChart, ShoppingCart 
} from 'lucide-react';

const services = [
  {
    title: 'App Development',
    description: 'We build custom Android applications tailored to your business needs and user expectations',
    icon: Smartphone,
    features: ['Native Android', 'Material Design', 'API Integration']
  },
  {
    title: 'UI/UX Design',
    description: 'Our design team creates intuitive and engaging user interfaces that enhance user experience',
    icon: Layout,
    features: ['Wireframing', 'Prototyping', 'User Testing']
  },
  {
    title: 'Backend Solutions',
    description: 'Robust backend services that power your Android applications with reliability and scalability',
    icon: Database,
    features: ['Cloud Services', 'Authentication', 'Real-time Data']
  },
  {
    title: 'App Maintenance',
    description: 'Ongoing support and updates to keep your Android applications running smoothly',
    icon: Code,
    features: ['Bug Fixes', 'OS Updates', 'Performance Optimization']
  },
  {
    title: 'Security Services',
    description: 'Implementing best practices for securing your Android applications and user data',
    icon: Shield,
    features: ['Data Encryption', 'Secure Auth', 'Vulnerability Testing']
  },
  {
    title: 'Support & Training',
    description: 'Comprehensive support and training for your team to manage your Android applications',
    icon: Headphones,
    features: ['24/7 Support', 'Documentation', 'Knowledge Transfer']
  },
  {
    title: 'Web Applications',
    description: 'Complementary web applications that work seamlessly with your Android solutions',
    icon: Monitor,
    features: ['Responsive Design', 'Cross-platform', 'PWA Support']
  },
  {
    title: 'Analytics Integration',
    description: 'Insightful analytics and reporting that help you understand user behavior and improve your app',
    icon: LineChart,
    features: ['User Insights', 'Performance Metrics', 'Conversion Tracking']
  },
  {
    title: 'E-commerce Solutions',
    description: 'Complete e-commerce functionality for Android applications with secure payment processing',
    icon: ShoppingCart,
    features: ['Payment Gateways', 'Shopping Cart', 'Order Management']
  }
];

const ServicesSection = () => {
  return (
    <section id="services" className="section-padding bg-[#0d0d0d]">
      <div className="container mx-auto px-4">
        <div className="section-heading">
          <h2>Our <span className="text-theme-purple">Services</span></h2>
          <p>We offer a comprehensive range of Android development services</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-12">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <div 
                key={service.title}
                className="bg-theme-dark-card rounded-lg p-6 card-hover animate-fade-in"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="flex items-center justify-center w-12 h-12 mb-4 rounded-md bg-theme-purple/20">
                  <Icon className="text-theme-purple" size={24} />
                </div>
                <h3 className="font-bold text-xl mb-3">{service.title}</h3>
                <p className="text-gray-400 mb-5">{service.description}</p>
                <div className="flex flex-wrap gap-2 mt-4">
                  {service.features.map((feature) => (
                    <span 
                      key={feature} 
                      className="text-xs text-gray-400 bg-theme-dark px-2 py-1 rounded-full"
                    >
                      {feature}
                    </span>
                  ))}
                </div>
                <a 
                  href="#" 
                  className="inline-block mt-6 text-theme-purple hover:text-theme-purple-light transition-colors"
                >
                  Learn more
                </a>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;

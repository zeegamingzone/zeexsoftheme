
import { Button } from './ui/button';

const categories = [
  { name: "All", value: "all", count: 12 },
  { name: "Android", value: "android", count: 5 },
  { name: "UI/UX", value: "ui-ux", count: 3 },
  { name: "Development", value: "development", count: 2 },
  { name: "Technology", value: "technology", count: 2 }
];

interface BlogCategoriesProps {
  activeCategory: string;
  onCategoryChange: (category: string) => void;
}

const BlogCategories = ({ activeCategory, onCategoryChange }: BlogCategoriesProps) => {
  return (
    <div className="card-bg rounded-xl p-6 h-fit dark:shadow-theme-purple/10 shadow-lg">
      <h3 className="text-xl font-bold mb-6">Categories</h3>
      <div className="space-y-3">
        {categories.map((category) => (
          <div 
            key={category.value} 
            onClick={() => onCategoryChange(category.value)}
            className={`flex items-center justify-between p-3 rounded-lg cursor-pointer transition-colors ${
              activeCategory === category.value 
                ? 'dark:bg-theme-purple/20 bg-theme-purple/10 text-theme-purple' 
                : 'dark:hover:bg-theme-dark-card/50 hover:bg-gray-100'
            }`}
          >
            <span className="font-medium">{category.name}</span>
            <span className="dark:bg-theme-dark bg-gray-200 text-xs px-2 py-1 rounded-full">
              {category.count}
            </span>
          </div>
        ))}
      </div>
      
      <div className="mt-10">
        <h3 className="text-xl font-bold mb-6">Newsletter</h3>
        <p className="dark:text-gray-400 text-gray-600 mb-4">
          Stay updated with our latest articles and news
        </p>
        <form className="space-y-3">
          <input 
            type="email" 
            placeholder="Your email address" 
            className="w-full p-3 rounded-lg dark:bg-theme-dark-card bg-gray-100 dark:border-theme-dark-card border-gray-200 border" 
          />
          <Button className="button-primary w-full">
            Subscribe
          </Button>
        </form>
      </div>
    </div>
  );
};

export default BlogCategories;

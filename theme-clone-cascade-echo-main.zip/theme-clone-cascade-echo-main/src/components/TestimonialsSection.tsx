
import { useState } from 'react';
import { ChevronLeft, ChevronRight, Star } from 'lucide-react';

const testimonials = [
  {
    id: 1,
    name: 'Sarah Johnson',
    position: 'CEO at TechBridge',
    quote: 'Zest Soft transformed our business with their innovative Android application. The team was professional, responsive, and delivered beyond our expectations.',
    rating: 5,
    image: 'https://placehold.co/100x100/171717/9b87f5?text=SJ'
  },
  {
    id: 2,
    name: 'Michael Thompson',
    position: 'Founder of HealthPlus',
    quote: 'Working with Zest Soft was a game-changer for our healthcare app. They understood our unique requirements and delivered a secure, user-friendly application.',
    rating: 5,
    image: 'https://placehold.co/100x100/171717/9b87f5?text=MT'
  },
  {
    id: 3,
    name: 'Rachel Wilson',
    position: 'Product Manager at RetailConnect',
    quote: 'The e-commerce application developed by Zest Soft has increased our sales by 40%. Their attention to detail and focus on user experience is unmatched.',
    rating: 4,
    image: 'https://placehold.co/100x100/171717/9b87f5?text=RW'
  }
];

const TestimonialsSection = () => {
  const [activeIndex, setActiveIndex] = useState(0);

  const handleNext = () => {
    setActiveIndex((prev) => (prev + 1) % testimonials.length);
  };

  const handlePrev = () => {
    setActiveIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  return (
    <section id="testimonials" className="section-padding bg-[#0d0d0d]">
      <div className="container mx-auto px-4">
        <div className="section-heading">
          <h2>Client <span className="text-theme-purple">Testimonials</span></h2>
          <p>See what our clients say about working with us</p>
        </div>

        <div className="mt-16 relative">
          <div className="max-w-4xl mx-auto">
            <div className="relative overflow-hidden">
              <div 
                className="flex transition-transform duration-500 ease-in-out"
                style={{ transform: `translateX(-${activeIndex * 100}%)` }}
              >
                {testimonials.map((testimonial) => (
                  <div key={testimonial.id} className="w-full flex-shrink-0 px-4">
                    <div className="bg-theme-dark-card rounded-lg p-8 shadow-lg animate-fade-in">
                      <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6">
                        <div className="flex-shrink-0">
                          <div className="w-20 h-20 rounded-full overflow-hidden border-2 border-theme-purple">
                            <img 
                              src={testimonial.image} 
                              alt={testimonial.name} 
                              className="w-full h-full object-cover"
                            />
                          </div>
                        </div>
                        <div className="flex-grow">
                          <div className="flex items-center mb-2">
                            {[...Array(5)].map((_, i) => (
                              <Star 
                                key={i}
                                size={16}
                                fill={i < testimonial.rating ? "#9b87f5" : "none"}
                                className={i < testimonial.rating ? "text-theme-purple" : "text-gray-600"}
                              />
                            ))}
                          </div>
                          <p className="italic text-gray-300 mb-4">"{testimonial.quote}"</p>
                          <div>
                            <h4 className="font-bold">{testimonial.name}</h4>
                            <p className="text-sm text-gray-400">{testimonial.position}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="flex justify-center mt-8 gap-4">
              <button 
                onClick={handlePrev}
                className="w-10 h-10 rounded-full flex items-center justify-center border border-gray-700 text-gray-400 hover:text-white hover:border-theme-purple transition-colors"
                aria-label="Previous testimonial"
              >
                <ChevronLeft size={20} />
              </button>
              <div className="flex gap-2">
                {testimonials.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setActiveIndex(index)}
                    className={`w-2 h-2 rounded-full transition-all ${
                      activeIndex === index ? 'w-6 bg-theme-purple' : 'bg-gray-700'
                    }`}
                    aria-label={`Go to testimonial ${index + 1}`}
                  />
                ))}
              </div>
              <button 
                onClick={handleNext}
                className="w-10 h-10 rounded-full flex items-center justify-center border border-gray-700 text-gray-400 hover:text-white hover:border-theme-purple transition-colors"
                aria-label="Next testimonial"
              >
                <ChevronRight size={20} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;


import { Link } from 'react-router-dom';
import { Calendar, Clock, ArrowRight } from 'lucide-react';
import { Blog } from '@/types/blog';

const BlogCard = ({ blog }: { blog: Blog }) => {
  return (
    <div className="card-bg rounded-xl overflow-hidden h-full flex flex-col card-hover dark:shadow-theme-purple/10 shadow-xl transition-all duration-500">
      <Link to={`/blog/${blog.slug}`} className="group">
        <div className="relative overflow-hidden h-48">
          <img 
            src={blog.image} 
            alt={blog.title} 
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
          />
          <div className="absolute top-3 right-3 bg-theme-purple text-white text-xs px-3 py-1 rounded-full">
            {blog.category}
          </div>
        </div>
        
        <div className="p-6 flex-grow flex flex-col">
          <div className="flex items-center gap-4 text-sm dark:text-gray-400 text-gray-500 mb-3">
            <div className="flex items-center gap-1">
              <Calendar size={14} />
              <span>{blog.date}</span>
            </div>
            <div className="flex items-center gap-1">
              <Clock size={14} />
              <span>{blog.readTime} min read</span>
            </div>
          </div>
          
          <h3 className="text-xl font-bold mb-3 transition-colors group-hover:text-theme-purple">
            {blog.title}
          </h3>
          
          <p className="dark:text-gray-400 text-gray-600 mb-5 line-clamp-3">
            {blog.excerpt}
          </p>
          
          <div className="mt-auto flex items-center text-theme-purple font-medium group">
            <span>Read More</span>
            <ArrowRight size={16} className="ml-1 transition-all group-hover:translate-x-1" />
          </div>
        </div>
      </Link>
    </div>
  );
};

export default BlogCard;


import { useState } from 'react';
import { ArrowRight } from 'lucide-react';
import { Button } from './ui/button';

type Project = {
  id: number;
  title: string;
  description: string;
  image: string;
  category: string;
  link: string;
};

const projects: Project[] = [
  {
    id: 1,
    title: 'HealthTrack',
    description: 'Health monitoring app with real-time tracking and analytics',
    image: 'https://placehold.co/600x400/171717/9b87f5?text=Health+App',
    category: 'health',
    link: '#'
  },
  {
    id: 2,
    title: 'CryptoScan',
    description: 'Cryptocurrency portfolio management with market insights',
    image: 'https://placehold.co/600x400/171717/9b87f5?text=Crypto+App',
    category: 'finance',
    link: '#'
  },
  {
    id: 3,
    title: 'MealPrep',
    description: 'Meal planning and grocery shopping automation app',
    image: 'https://placehold.co/600x400/171717/9b87f5?text=Food+App',
    category: 'lifestyle',
    link: '#'
  },
  {
    id: 4,
    title: 'EC Store',
    description: 'E-commerce platform with AR product visualization',
    image: 'https://placehold.co/600x400/171717/9b87f5?text=E-Commerce',
    category: 'commerce',
    link: '#'
  },
  {
    id: 5,
    title: 'In The Loop',
    description: 'Social media app for neighborhood connections',
    image: 'https://placehold.co/600x400/171717/9b87f5?text=Social+App',
    category: 'social',
    link: '#'
  },
  {
    id: 6,
    title: 'Nomada',
    description: 'Travel planning app with AI-powered recommendations',
    image: 'https://placehold.co/600x400/171717/9b87f5?text=Travel+App',
    category: 'travel',
    link: '#'
  }
];

const categories = ['all', 'health', 'finance', 'lifestyle', 'commerce', 'social', 'travel'];

const PortfolioSection = () => {
  const [activeCategory, setActiveCategory] = useState('all');
  const [visibleCount, setVisibleCount] = useState(6);
  const [hoveredProject, setHoveredProject] = useState<number | null>(null);
  
  const filteredProjects = activeCategory === 'all' 
    ? projects 
    : projects.filter(project => project.category === activeCategory);
  
  const displayedProjects = filteredProjects.slice(0, visibleCount);
  
  const loadMore = () => {
    setVisibleCount(prev => prev + 3);
  };
  
  return (
    <section id="portfolio" className="section-padding dark:bg-theme-dark bg-white">
      <div className="container mx-auto px-4">
        <div className="section-heading">
          <h2>Our <span className="text-theme-purple">Portfolio</span></h2>
          <p className="dark:text-gray-400 text-gray-600">Explore our recent Android development projects</p>
        </div>
        
        <div className="flex justify-center flex-wrap gap-2 mb-10">
          {categories.map((category) => (
            <button
              key={category}
              className={`px-4 py-2 rounded-full capitalize transition-all ${
                activeCategory === category 
                  ? 'bg-theme-purple text-white shadow-lg shadow-theme-purple/20' 
                  : 'dark:bg-theme-dark-card bg-gray-100 dark:text-gray-400 text-gray-600 hover:text-theme-purple'
              }`}
              onClick={() => setActiveCategory(category)}
            >
              {category}
            </button>
          ))}
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-12">
          {displayedProjects.map((project, index) => (
            <div 
              key={project.id} 
              className="dark:bg-theme-dark-card bg-white rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-all duration-500 animate-fade-in"
              style={{ animationDelay: `${index * 100}ms` }}
              onMouseEnter={() => setHoveredProject(project.id)}
              onMouseLeave={() => setHoveredProject(null)}
            >
              <div className="h-48 overflow-hidden">
                <img 
                  src={project.image} 
                  alt={project.title} 
                  className={`w-full h-full object-cover transition-all duration-700 ${
                    hoveredProject === project.id ? 'scale-110 rotate-1' : 'scale-100'
                  }`}
                />
                {hoveredProject === project.id && (
                  <div className="absolute inset-0 bg-theme-purple/80 flex items-center justify-center opacity-0 animate-fade-in p-6">
                    <div className="text-white text-center">
                      <p className="mb-4">Innovative Android solution with cutting-edge features</p>
                      <Button variant="secondary" size="sm" className="bg-white text-theme-purple hover:bg-gray-100">
                        View Details
                      </Button>
                    </div>
                  </div>
                )}
              </div>
              <div className="p-6">
                <h3 className="font-bold text-xl mb-2 group-hover:text-theme-purple transition-colors">{project.title}</h3>
                <p className="dark:text-gray-400 text-gray-600 mb-4">{project.description}</p>
                <a 
                  href={project.link} 
                  className="inline-flex items-center text-theme-purple hover:text-theme-purple-light transition-colors gap-1 group"
                >
                  <span className="relative">
                    View Case Study
                    <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-theme-purple-light transition-all duration-300 group-hover:w-full"></span>
                  </span>
                  <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
                </a>
              </div>
            </div>
          ))}
        </div>
        
        {filteredProjects.length > visibleCount && (
          <div className="flex justify-center mt-10">
            <Button 
              variant="outline" 
              className="button-outline hover:scale-105 transition-transform"
              onClick={loadMore}
            >
              Load More Projects
            </Button>
          </div>
        )}
      </div>
    </section>
  );
};

export default PortfolioSection;

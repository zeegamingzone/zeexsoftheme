
import { Link } from 'react-router-dom';
import { Calendar, Clock, ArrowRight } from 'lucide-react';
import { Blog } from '@/types/blog';

const BlogFeatured = ({ blog }: { blog: Blog }) => {
  return (
    <div className="card-bg rounded-xl overflow-hidden dark:shadow-theme-purple/10 shadow-xl animate-fade-in">
      <div className="grid grid-cols-1 lg:grid-cols-2">
        <div className="relative overflow-hidden h-64 lg:h-auto">
          <img 
            src={blog.image} 
            alt={blog.title} 
            className="w-full h-full object-cover"
          />
          <div className="absolute top-4 left-4 bg-theme-purple text-white px-4 py-2 rounded-full">
            Featured
          </div>
        </div>
        
        <div className="p-8">
          <div className="flex items-center gap-4 text-sm dark:text-gray-400 text-gray-500 mb-4">
            <div className="flex items-center gap-1">
              <Calendar size={16} />
              <span>{blog.date}</span>
            </div>
            <div className="flex items-center gap-1">
              <Clock size={16} />
              <span>{blog.readTime} min read</span>
            </div>
            <div className="bg-theme-purple/20 text-theme-purple text-xs px-3 py-1 rounded-full">
              {blog.category}
            </div>
          </div>
          
          <h2 className="text-2xl md:text-3xl font-bold mb-4">
            {blog.title}
          </h2>
          
          <p className="dark:text-gray-400 text-gray-600 mb-6">
            {blog.excerpt}
          </p>
          
          <Link to={`/blog/${blog.slug}`} className="flex items-center text-theme-purple font-medium group">
            <span>Read Full Article</span>
            <ArrowRight size={18} className="ml-2 transition-all group-hover:translate-x-1" />
          </Link>
        </div>
      </div>
    </div>
  );
};

export default BlogFeatured;

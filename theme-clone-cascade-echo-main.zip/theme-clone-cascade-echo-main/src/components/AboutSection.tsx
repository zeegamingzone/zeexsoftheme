
import { CheckCircle } from 'lucide-react';

const AboutSection = () => {
  const techStack = [
    'Kotlin', 'Java', 'Android Studio', 'Firebase',
    'Jetpack Compose', 'Material Design', 'Retrofit'
  ];

  return (
    <section id="about" className="section-padding section-bg">
      <div className="container mx-auto px-4">
        <div className="section-heading">
          <h2 className="dark:text-white text-gray-900">About <span className="text-theme-purple">Zest Soft</span></h2>
          <p className="dark:text-gray-400 text-gray-600">Learn more about our passionate team of Android developers</p>
        </div>

        <div className="flex flex-col lg:flex-row gap-12 items-center">
          <div className="lg:w-1/2 animate-fade-in" style={{ animationDelay: '100ms' }}>
            <img 
              src="https://placehold.co/600x400/171717/9b87f5?text=Our+Story" 
              alt="Our Team" 
              className="rounded-lg shadow-xl" 
            />
          </div>

          <div className="lg:w-1/2 space-y-6 animate-fade-in" style={{ animationDelay: '300ms' }}>
            <h3 className="font-bold text-theme-purple">Our Story</h3>
            <p className="dark:text-gray-300 text-gray-700">
              Founded in 2013, Zest Soft has grown from a small team of passionate Android developers into a full-service mobile application development agency trusted by businesses worldwide.
            </p>
            <p className="dark:text-gray-400 text-gray-600">
              We specialize in creating beautiful, functional, and innovative Android applications that solve real problems and deliver exceptional user experiences. Our team combines technical expertise with creative thinking to transform your ideas into reality.
            </p>

            <div className="pt-4">
              <h4 className="font-bold mb-4 dark:text-white text-gray-900">Our Tech Stack</h4>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {techStack.map((tech) => (
                  <div key={tech} className="flex items-center gap-2">
                    <CheckCircle size={18} className="text-theme-purple" />
                    <span className="dark:text-white text-gray-800">{tech}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;

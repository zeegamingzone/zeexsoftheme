
import { ArrowRight, Sparkle, Zap } from 'lucide-react';
import { Button } from './ui/button';
import { useEffect, useRef } from 'react';

const HeroSection = () => {
  const logoRef = useRef<HTMLDivElement>(null);
  
  // Enhanced entrance animations
  useEffect(() => {
    const animateElements = () => {
      const elements = document.querySelectorAll('.hero-animate');
      elements.forEach((el, index) => {
        setTimeout(() => {
          el.classList.add('animate-fade-in');
          el.classList.remove('opacity-0');
        }, index * 120); // Faster staggered animation
      });
    };

    // Run animation after a shorter delay
    setTimeout(animateElements, 50);

    // 3D tilt effect for the logo
    const handleLogoTilt = (e: MouseEvent) => {
      if (!logoRef.current) return;
      
      const logo = logoRef.current;
      const rect = logo.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      
      const centerX = rect.width / 2;
      const centerY = rect.height / 2;
      
      const tiltX = (y - centerY) / 10;
      const tiltY = -(x - centerX) / 10;
      
      logo.style.transform = `perspective(1000px) rotateX(${tiltX}deg) rotateY(${tiltY}deg) scale3d(1.05, 1.05, 1.05)`;
    };
    
    const handleLogoReset = () => {
      if (!logoRef.current) return;
      logoRef.current.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)';
    };
    
    const logo = logoRef.current;
    if (logo) {
      logo.addEventListener('mousemove', handleLogoTilt);
      logo.addEventListener('mouseleave', handleLogoReset);
    }
    
    // Particle animation effect
    const createParticles = () => {
      const particleContainer = document.getElementById('particle-container');
      if (!particleContainer) return;
      
      // Clear existing particles
      particleContainer.innerHTML = '';
      
      for (let i = 0; i < 50; i++) { // More particles
        const particle = document.createElement('div');
        particle.className = 'absolute rounded-full bg-theme-purple/20 animate-pulse';
        
        // Random size between 5px and 25px
        const size = Math.random() * 20 + 5;
        particle.style.width = `${size}px`;
        particle.style.height = `${size}px`;
        
        // Random position
        particle.style.left = `${Math.random() * 100}%`;
        particle.style.top = `${Math.random() * 100}%`;
        
        // Random animation duration
        particle.style.animationDuration = `${Math.random() * 3 + 1}s`; // Faster animation
        
        // Random delay
        particle.style.animationDelay = `${Math.random() * 1}s`; // Shorter delay
        
        particleContainer.appendChild(particle);
      }
    };
    
    createParticles();
    
    // Recreate particles more frequently
    const particleInterval = setInterval(createParticles, 5000);
    
    return () => {
      clearInterval(particleInterval);
      if (logo) {
        logo.removeEventListener('mousemove', handleLogoTilt);
        logo.removeEventListener('mouseleave', handleLogoReset);
      }
    };
  }, []);

  return (
    <section id="home" className="min-h-screen flex items-center pt-16 overflow-hidden relative dark:bg-gradient-to-br dark:from-theme-dark dark:to-[#161a23] bg-gradient-to-br from-white to-gray-100">
      {/* Particle effect container */}
      <div id="particle-container" className="absolute inset-0 overflow-hidden pointer-events-none"></div>
      
      {/* Abstract shapes with enhanced animations */}
      <div className="absolute top-[10%] right-[5%] w-64 h-64 rounded-full bg-theme-purple/10 blur-3xl animate-pulse"></div>
      <div className="absolute bottom-[10%] left-[5%] w-80 h-80 rounded-full bg-theme-purple/10 blur-3xl animate-pulse" style={{animationDuration: '4s'}}></div>
      <div className="absolute top-[30%] left-[15%] w-32 h-32 rounded-full bg-blue-500/10 blur-2xl animate-pulse" style={{animationDuration: '3s'}}></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-10">
          <div className="lg:w-1/2 space-y-6">
            <div ref={logoRef} className="hero-animate opacity-0 transition-all duration-300 ease-out cursor-pointer">
              <div className="w-32 h-32 rounded-2xl bg-gradient-to-br from-theme-purple to-blue-600 flex items-center justify-center text-white overflow-hidden relative shadow-2xl shadow-theme-purple/30 mb-6">
                {/* Dynamic background animation */}
                <div className="absolute inset-0 bg-gradient-to-br from-theme-purple via-blue-500 to-purple-700 animate-gradient opacity-80"></div>
                
                {/* Sparkle effects */}
                <Sparkle className="absolute top-2 left-2 text-white/70 animate-pulse" size={16} />
                <Sparkle className="absolute bottom-3 right-3 text-white/70 animate-pulse" size={14} style={{animationDelay: '0.5s'}} />
                <Zap className="absolute bottom-2 left-6 text-white/70 animate-pulse" size={16} style={{animationDelay: '1s'}} />
                
                {/* Logo text with 3D effect */}
                <div className="relative z-10 flex flex-col items-center">
                  <span className="font-extrabold text-5xl tracking-tighter mt-1 shadow-text">ZX</span>
                  <span className="text-xs font-light tracking-widest text-white/90 uppercase mt-0.5">SOFT</span>
                </div>
              </div>
            </div>
            
            <h1 className="font-bold leading-tight dark:text-white text-gray-900 hero-animate opacity-0">
              Crafting <span className="gradient-text">Innovative</span> <br />
              Android <span className="gradient-text">Experiences</span>
            </h1>
            
            <p className="dark:text-gray-400 text-gray-600 text-lg max-w-xl hero-animate opacity-0">
              Transformatively design and implement cutting-edge Android applications for your business needs with our expert team
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 pt-4 hero-animate opacity-0">
              <Button className="button-primary flex items-center gap-2 group">
                Get Started
                <ArrowRight size={18} className="transition-transform group-hover:translate-x-1" />
              </Button>
              <Button variant="outline" className="button-outline">
                View Our Work
              </Button>
            </div>
            
            <div className="flex items-center gap-8 pt-6 hero-animate opacity-0">
              <div className="flex flex-col">
                <span className="text-3xl font-bold text-theme-purple">100+</span>
                <span className="text-sm dark:text-gray-400 text-gray-600">Projects</span>
              </div>
              <div className="h-10 w-px dark:bg-gray-700 bg-gray-300"></div>
              <div className="flex flex-col">
                <span className="text-3xl font-bold text-theme-purple">50+</span>
                <span className="text-sm dark:text-gray-400 text-gray-600">Clients</span>
              </div>
              <div className="h-10 w-px dark:bg-gray-700 bg-gray-300"></div>
              <div className="flex flex-col">
                <span className="text-3xl font-bold text-theme-purple">10+</span>
                <span className="text-sm dark:text-gray-400 text-gray-600">Years</span>
              </div>
            </div>
          </div>

          <div className="lg:w-1/2 flex justify-center lg:justify-end hero-animate opacity-0">
            <div className="relative">
              <div className="absolute -inset-4 rounded-full bg-theme-purple/20 blur-3xl animate-pulse" style={{animationDuration: '3s'}}></div>
              <img 
                src="https://images.unsplash.com/photo-1607252650355-f7fd0460ccdb?ixlib=rb-1.2.1&auto=format&fit=crop&w=1100&q=80" 
                alt="Android Device" 
                className="relative z-10 max-h-[600px] object-contain rounded-3xl shadow-2xl shadow-theme-purple/20 hover:scale-105 transition-all duration-500" 
              />
              
              {/* Floating elements with faster animations */}
              <div className="absolute -top-10 -left-10 w-24 h-24 bg-theme-purple/10 backdrop-blur-sm rounded-2xl rotate-12 animate-bounce" style={{animationDuration: '4s'}}></div>
              <div className="absolute -bottom-5 -right-5 w-32 h-32 bg-theme-purple/10 backdrop-blur-sm rounded-full animate-bounce" style={{animationDuration: '5s'}}></div>
              <div className="absolute top-1/2 -right-16 w-20 h-20 bg-theme-purple/20 backdrop-blur-sm rounded-lg rotate-45 animate-bounce" style={{animationDuration: '3.5s'}}></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;


import { useRef } from 'react';
import { Check } from 'lucide-react';

const steps = [
  {
    number: '01',
    title: 'Analysis',
    description: 'We analyze your requirements, target audience, and market to define the scope of your Android project.'
  },
  {
    number: '02',
    title: 'Design',
    description: 'Our UI/UX designers create wireframes and visual designs for an intuitive and engaging user experience.'
  },
  {
    number: '03',
    title: 'Development',
    description: 'Our Android developers write clean, efficient code following best practices and the latest Android guidelines.'
  },
  {
    number: '04',
    title: 'Quality Assurance',
    description: 'We thoroughly test your application across various devices and scenarios to ensure quality and reliability.'
  },
  {
    number: '05',
    title: 'Deployment',
    description: 'We handle the publishing process to the Google Play Store, ensuring your app meets all requirements.'
  }
];

const ProcessSection = () => {
  const processRef = useRef<HTMLDivElement>(null);

  return (
    <section id="process" className="section-padding dark:bg-theme-dark bg-white" ref={processRef}>
      <div className="container mx-auto px-4">
        <div className="section-heading">
          <h2>Our Development <span className="text-theme-purple">Process</span></h2>
          <p className="dark:text-gray-400 text-gray-600">Our proven methodology for building successful Android applications</p>
        </div>

        <div className="mt-16 mb-16">
          <div className="relative">
            <div className="hidden md:block h-1 dark:bg-theme-dark-card bg-gray-200 absolute top-8 left-0 right-0 z-0">
              <div 
                className="h-full bg-theme-purple transition-all duration-700 ease-in-out" 
                style={{ width: `100%` }}
              ></div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-5 gap-8">
              {steps.map((step, index) => (
                <div 
                  key={step.number} 
                  className="relative flex flex-col items-center animate-fade-in"
                  style={{ animationDelay: `${index * 200}ms` }}
                >
                  <div className={`
                    w-16 h-16 rounded-full flex items-center justify-center z-10 transition-all
                    ${index < 2
                      ? 'bg-theme-purple text-white shadow-lg shadow-theme-purple/20' 
                      : 'dark:bg-theme-dark-card bg-gray-100 dark:text-gray-400 text-gray-600'
                    }
                  `}>
                    {index < 2 ? (
                      <Check size={24} className="text-white" />
                    ) : (
                      <span className="font-bold text-lg">{step.number}</span>
                    )}
                  </div>
                  <h3 className="mt-6 text-xl font-bold dark:text-white text-gray-900">{step.title}</h3>
                  <p className="mt-2 text-center dark:text-gray-400 text-gray-600">{step.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-20 relative">
          <div className="absolute -inset-2 bg-theme-purple/10 blur-3xl rounded-3xl"></div>
          <div className="relative dark:bg-theme-dark-card bg-white rounded-lg overflow-hidden shadow-xl">
            <div className="p-8 md:p-12">
              <div className="flex flex-col md:flex-row items-center gap-8">
                <div className="md:w-2/3 space-y-4">
                  <h3 className="font-bold text-2xl dark:text-white text-gray-900">Let's Build Your Android Application</h3>
                  <p className="dark:text-gray-400 text-gray-600">
                    Ready to transform your idea into a powerful Android application? 
                    Our team is ready to guide you through our development process.
                  </p>
                </div>
                <div className="md:w-1/3 flex justify-center md:justify-end">
                  <img 
                    src="https://placehold.co/400x300/171717/9b87f5?text=Code" 
                    alt="Development" 
                    className="rounded-lg w-full max-w-sm shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-300"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProcessSection;


import { useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Calendar, Clock, User, ArrowLeft } from 'lucide-react';
import { Button } from './ui/button';
import Navigation from './Navigation';
import Footer from './Footer';
import { sampleBlogs } from '@/data/sampleBlogs';

const BlogDetail = () => {
  const { slug } = useParams<{ slug: string }>();
  const blog = sampleBlogs.find(blog => blog.slug === slug);
  
  useEffect(() => {
    window.scrollTo(0, 0);
    
    // Animation for content sections
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('animate-fade-in');
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.1 }
    );
    
    document.querySelectorAll('.blog-section').forEach(section => {
      observer.observe(section);
    });
    
    return () => observer.disconnect();
  }, []);
  
  if (!blog) {
    return (
      <div className="flex flex-col min-h-screen">
        <Navigation />
        <div className="container mx-auto px-4 pt-32 pb-16 text-center">
          <h1 className="text-3xl font-bold mb-6">Blog Post Not Found</h1>
          <p className="dark:text-gray-400 text-gray-600 mb-8">
            The blog post you're looking for doesn't exist or has been removed.
          </p>
          <Link to="/blog">
            <Button className="button-primary">
              Back to Blog
            </Button>
          </Link>
        </div>
        <Footer />
      </div>
    );
  }
  
  return (
    <div className="flex flex-col min-h-screen">
      <Navigation />
      <main className="flex-grow pt-24">
        {/* Hero Banner */}
        <section className="relative overflow-hidden pb-10 mb-10">
          <div className="absolute inset-0">
            <div className="absolute inset-0 bg-gradient-to-b dark:from-theme-dark/90 dark:to-theme-dark from-gray-900/70 to-gray-900"></div>
            <img 
              src={blog.image} 
              alt={blog.title} 
              className="w-full h-full object-cover"
            />
          </div>
          
          <div className="container mx-auto px-4 py-16 relative">
            <Link to="/blog" className="inline-flex items-center text-white bg-theme-purple/30 backdrop-blur-sm px-4 py-2 rounded-full mb-8 hover:bg-theme-purple/50 transition-colors">
              <ArrowLeft size={16} className="mr-2" />
              Back to all blogs
            </Link>
            
            <div className="max-w-3xl">
              <div className="flex flex-wrap items-center gap-4 text-sm text-white/80 mb-4">
                <div className="flex items-center gap-1">
                  <Calendar size={16} />
                  <span>{blog.date}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Clock size={16} />
                  <span>{blog.readTime} min read</span>
                </div>
                <div className="flex items-center gap-1">
                  <User size={16} />
                  <span>{blog.author}</span>
                </div>
                <div className="bg-theme-purple/30 text-white text-xs px-3 py-1 rounded-full">
                  {blog.category}
                </div>
              </div>
              
              <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
                {blog.title}
              </h1>
              
              <p className="text-white/90 text-xl">
                {blog.excerpt}
              </p>
            </div>
          </div>
        </section>
        
        <div className="container mx-auto px-4 pb-16">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-8">
              <div className="card-bg rounded-xl overflow-hidden dark:shadow-theme-purple/10 shadow-lg p-8">
                <div className="prose dark:prose-invert prose-lg max-w-none">
                  {blog.content.map((section, index) => (
                    <div key={index} className="blog-section opacity-0" style={{ animationDelay: `${index * 100}ms` }}>
                      {section.type === 'heading' && (
                        <h2 className="text-2xl font-bold mt-8 mb-4">{section.content}</h2>
                      )}
                      
                      {section.type === 'paragraph' && (
                        <p className="mb-4">{section.content}</p>
                      )}
                      
                      {section.type === 'image' && (
                        <div className="my-8">
                          <img 
                            src={section.content} 
                            alt={section.alt || "Blog content"} 
                            className="w-full h-auto rounded-lg"
                          />
                          {section.caption && (
                            <p className="text-center text-sm dark:text-gray-400 text-gray-500 mt-2">
                              {section.caption}
                            </p>
                          )}
                        </div>
                      )}
                      
                      {section.type === 'code' && (
                        <pre className="bg-gray-900 text-gray-100 p-4 rounded-lg overflow-x-auto mb-6">
                          <code>{section.content}</code>
                        </pre>
                      )}
                      
                      {section.type === 'list' && (
                        <ul className="list-disc list-inside mb-6 space-y-2">
                          {section.items.map((item, i) => (
                            <li key={i}>{item}</li>
                          ))}
                        </ul>
                      )}
                    </div>
                  ))}
                </div>
                
                <div className="border-t dark:border-gray-700 border-gray-200 mt-10 pt-8">
                  <h3 className="text-xl font-bold mb-4">Share this article</h3>
                  <div className="flex gap-3">
                    {['Twitter', 'Facebook', 'LinkedIn'].map(platform => (
                      <Button key={platform} variant="outline" size="sm">
                        {platform}
                      </Button>
                    ))}
                  </div>
                </div>
              </div>
              
              {/* Author Bio */}
              <div className="card-bg rounded-xl dark:shadow-theme-purple/10 shadow-lg p-6 mt-8 flex items-center gap-6">
                <div className="w-20 h-20 rounded-full overflow-hidden flex-shrink-0">
                  <img 
                    src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=300&h=300&q=80" 
                    alt="Author" 
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <h4 className="text-lg font-bold">{blog.author}</h4>
                  <p className="dark:text-gray-400 text-gray-600 mb-2">
                    Senior Android Developer at ZeeX Soft
                  </p>
                  <p className="text-sm">
                    Experienced Android developer with a passion for creating intuitive, high-performance applications.
                  </p>
                </div>
              </div>
            </div>
            
            {/* Sidebar */}
            <div className="lg:col-span-4 space-y-8">
              {/* Related Posts */}
              <div className="card-bg rounded-xl overflow-hidden dark:shadow-theme-purple/10 shadow-lg p-6">
                <h3 className="text-xl font-bold mb-6">Related Articles</h3>
                <div className="space-y-4">
                  {sampleBlogs
                    .filter(post => post.category === blog.category && post.id !== blog.id)
                    .slice(0, 3)
                    .map(post => (
                      <Link key={post.id} to={`/blog/${post.slug}`} className="flex gap-4 group">
                        <div className="w-20 h-20 rounded-lg overflow-hidden flex-shrink-0">
                          <img 
                            src={post.image} 
                            alt={post.title} 
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div>
                          <h4 className="font-medium group-hover:text-theme-purple transition-colors">
                            {post.title}
                          </h4>
                          <div className="flex items-center gap-2 text-xs dark:text-gray-400 text-gray-500 mt-1">
                            <Calendar size={12} />
                            <span>{post.date}</span>
                          </div>
                        </div>
                      </Link>
                    ))}
                </div>
              </div>
              
              {/* Tags */}
              <div className="card-bg rounded-xl overflow-hidden dark:shadow-theme-purple/10 shadow-lg p-6">
                <h3 className="text-xl font-bold mb-6">Tags</h3>
                <div className="flex flex-wrap gap-2">
                  {['Android', 'Kotlin', 'MVVM', 'Material Design', 'Jetpack Compose', 'LiveData', 'Coroutines', 'UI/UX']
                    .map(tag => (
                      <div 
                        key={tag} 
                        className="bg-theme-purple/10 dark:bg-theme-purple/20 text-theme-purple px-3 py-1 rounded-full text-sm"
                      >
                        {tag}
                      </div>
                    ))}
                </div>
              </div>
              
              {/* Newsletter */}
              <div className="card-bg rounded-xl overflow-hidden dark:shadow-theme-purple/10 shadow-lg p-6">
                <h3 className="text-xl font-bold mb-4">Newsletter</h3>
                <p className="dark:text-gray-400 text-gray-600 mb-4">
                  Get the latest ZeeX Soft blogs directly to your inbox
                </p>
                <form className="space-y-3">
                  <input 
                    type="email" 
                    placeholder="Your email address" 
                    className="w-full p-3 rounded-lg dark:bg-theme-dark-card bg-gray-100 dark:border-theme-dark-card border-gray-200 border" 
                  />
                  <Button className="button-primary w-full">
                    Subscribe
                  </Button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default BlogDetail;

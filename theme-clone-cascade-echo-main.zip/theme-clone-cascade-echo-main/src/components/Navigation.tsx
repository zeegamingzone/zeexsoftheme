
import { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';
import { Button } from './ui/button';
import ThemeToggle from './ThemeToggle';
import { Link } from 'react-router-dom';

const Navigation = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <header className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
      isScrolled 
        ? 'dark:bg-theme-dark/90 dark:backdrop-blur-sm dark:shadow-md bg-white/90 backdrop-blur-sm shadow-md' 
        : 'bg-transparent'
    }`}>
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link to="/" className="text-2xl font-bold dark:text-white text-gray-900 flex items-center gap-2">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-theme-purple to-blue-500 flex items-center justify-center text-white font-bold shadow-lg shadow-theme-purple/25 overflow-hidden relative">
              <span className="absolute inset-0 bg-gradient-to-br from-theme-purple via-blue-500 to-purple-700 animate-gradient"></span>
              <span className="relative z-10 flex items-center justify-center font-extrabold text-white tracking-tighter">ZX</span>
            </div>
            <span className="text-theme-purple">ZeeX</span> Soft
          </Link>

          <div className="hidden md:flex items-center space-x-10">
            <nav>
              <ul className="flex space-x-8">
                {[
                  {name: 'Home', path: '/'}, 
                  {name: 'Blog', path: '/blog'}, 
                  {name: 'About', path: '/#about'}, 
                  {name: 'Portfolio', path: '/#portfolio'}, 
                  {name: 'Services', path: '/#services'}, 
                  {name: 'Testimonials', path: '/#testimonials'}
                ].map((item) => (
                  <li key={item.name}>
                    <Link 
                      to={item.path} 
                      className="dark:text-gray-300 text-gray-700 hover:text-theme-purple transition-colors"
                    >
                      {item.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </nav>
            <div className="flex items-center gap-4">
              <ThemeToggle />
              <Button className="button-primary">
                Contact Us
              </Button>
            </div>
          </div>

          <div className="md:hidden flex items-center gap-4">
            <ThemeToggle />
            <button 
              className="dark:text-white text-gray-900" 
              onClick={toggleMobileMenu}
              aria-label="Toggle mobile menu"
            >
              {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <div 
        className={`md:hidden dark:bg-theme-dark-card bg-white absolute w-full ${
          isMobileMenuOpen ? 'max-h-screen opacity-100 visible' : 'max-h-0 opacity-0 invisible'
        } transition-all duration-300 overflow-hidden`}
      >
        <nav className="container mx-auto px-4 py-6">
          <ul className="flex flex-col space-y-6">
            {[
              {name: 'Home', path: '/'}, 
              {name: 'Blog', path: '/blog'}, 
              {name: 'About', path: '/#about'}, 
              {name: 'Portfolio', path: '/#portfolio'}, 
              {name: 'Services', path: '/#services'}, 
              {name: 'Testimonials', path: '/#testimonials'}
            ].map((item) => (
              <li key={item.name}>
                <Link 
                  to={item.path} 
                  className="dark:text-gray-300 text-gray-700 hover:text-theme-purple transition-colors text-lg"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  {item.name}
                </Link>
              </li>
            ))}
            <li>
              <Button className="button-primary w-full">
                Contact Us
              </Button>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
};

export default Navigation;

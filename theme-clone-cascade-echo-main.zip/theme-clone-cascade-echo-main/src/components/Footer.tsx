
import { Facebook, Twitter, Instagram, Linkedin, Github } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-[#0a0a0a] pt-12 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-theme-purple to-blue-500 flex items-center justify-center text-white font-bold shadow-md">
                <span className="relative z-10 flex items-center justify-center font-extrabold text-xs">ZX</span>
              </div>
              <span className="text-theme-purple">ZeeX</span> Soft
            </div>
            <p className="text-gray-400 mb-6">
              We are passionate about creating innovative Android experiences that drive your business forward.
            </p>
            <div className="flex space-x-4">
              {[Facebook, Twitter, Instagram, Linkedin, Github].map((Icon, index) => (
                <a 
                  key={index}
                  href="#" 
                  className="w-10 h-10 rounded-full bg-theme-dark-card flex items-center justify-center text-gray-400 hover:bg-theme-purple hover:text-white transition-colors"
                >
                  <Icon size={18} />
                </a>
              ))}
            </div>
          </div>
          
          <div>
            <h3 className="font-bold text-lg mb-4">Links</h3>
            <ul className="space-y-3">
              {['Home', 'About', 'Portfolio', 'Services', 'Testimonials', 'Contact'].map((item) => (
                <li key={item}>
                  <a 
                    href={`#${item.toLowerCase()}`} 
                    className="text-gray-400 hover:text-theme-purple transition-colors inline-block"
                  >
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="font-bold text-lg mb-4">Services</h3>
            <ul className="space-y-3">
              {[
                'Android App Development', 
                'UI/UX Design', 
                'Backend Solutions',
                'App Maintenance',
                'Security Services',
                'Support & Training'
              ].map((item) => (
                <li key={item}>
                  <a 
                    href="#services" 
                    className="text-gray-400 hover:text-theme-purple transition-colors inline-block"
                  >
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="font-bold text-lg mb-4">Newsletter</h3>
            <p className="text-gray-400 mb-4">
              Subscribe to our newsletter to receive updates on our latest projects and Android development insights.
            </p>
            <form className="flex">
              <input 
                type="email" 
                placeholder="Your email"
                className="flex-grow px-4 py-2 bg-theme-dark rounded-l-md border border-gray-800 focus:outline-none focus:border-theme-purple"
              />
              <button 
                type="submit"
                className="bg-theme-purple px-4 py-2 rounded-r-md text-white hover:bg-theme-purple-dark"
              >
                Subscribe
              </button>
            </form>
          </div>
        </div>
        
        <div className="pt-6 border-t border-gray-800 text-center">
          <p className="text-gray-500 text-sm">
            © {currentYear} ZeeX Soft. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
